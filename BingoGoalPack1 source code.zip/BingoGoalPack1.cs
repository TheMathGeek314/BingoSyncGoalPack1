﻿using BingoGoalPack1.CustomVariables;
using BingoSyncExtension;
using Modding;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Reflection;
using MonoMod.Utils;
using MonoMod.RuntimeDetour;

namespace BingoGoalPack1 {
    public class BingoGoalPack1: Mod {
        internal static BingoGoalPack1 Instance;
        new public string GetName() => "BingoGoalPack1";
        public override string GetVersion() => "1.0.0.0";
        public override int LoadPriority() => 8;
        public override void Initialize(Dictionary<string, Dictionary<string, GameObject>> preloadedObjects) {
            Instance = this;
            VariableProxy.Setup(Log);

            string hk_data = BingoSquareReader.GetHKDataFolderName();
            string path = @$".\{hk_data}\Managed\Mods\";

            List<LocalBingoSquare> listOfSquares = BingoSquareReader.ReadFromFile(path + "BingoGoalPack1\\Squares\\Extended.json");
            List<LocalBingoSquare> listOfSquares2 = BingoSquareReader.ReadFromFile(path + "BingoGoalPack1\\Squares\\BenchBingo.json");
            List<LocalBingoSquare> listOfSquares3 = BingoSquareReader.ReadFromFile(path + "BingoGoalPack1\\Squares\\GrubBingo.json");
            List<LocalBingoSquare> listOfSquares4 = BingoSquareReader.ReadFromFile(path + "BingoGoalPack1\\Squares\\GodhomeBingo.json");
            BingoSquareInjector.InjectSquares(listOfSquares);
            BingoSquareInjector.InjectSquares(listOfSquares2);
            BingoSquareInjector.InjectSquares(listOfSquares3);
            BingoSquareInjector.InjectSquares(listOfSquares4);

            On.GameManager.AwardAchievement += Neglect.CheckNeglectAchievement;
            ModHooks.SetPlayerBoolHook += CoreShard.CheckIfCoreShardWasCollected;
            On.PlayMakerFSM.OnEnable += Totems.CreateSoulTotemTrigger;
            On.DialogueBox.StartConversation += DialogueExtension.StartConversation;
            ModHooks.SetPlayerIntHook += GrubsExtension.CheckIfGrubWasSaved;
            On.PlayMakerFSM.OnEnable += Diary.CreateDiaryTrigger;
            On.PlayMakerFSM.OnEnable += Arenas.CreateArenaTrigger;
            On.PlayMakerFSM.OnEnable += ChestsExtension.CreateJunkpitChestTrigger;
            On.PlayMakerFSM.OnEnable += Hardsaves.CreateHardsaveTrigger;
            On.RespawnTrigger.OnTriggerEnter2D += Hardsaves.CreateRespawnTriggerTrigger;
            On.PlayMakerFSM.OnEnable += GrubsExtension.SaveOneGrub;
            On.PlayMakerFSM.OnEnable += Ghosts.CreateGhostKilledTrigger;
            On.PlayMakerFSM.OnEnable += DreamNailMace.CreateMaceTrigger;
            On.BossStatue.SetPlaqueState += HallOfGodsTracker.CreateHogStatueTrigger;

            var _hook = new ILHook
            (
                typeof(DreamPlant).GetMethod("CheckOrbs", BindingFlags.NonPublic | BindingFlags.Instance).GetStateMachineTarget(),
                DreamTreesExtension.TrackDreamTrees
            );

            Log("Initialized");
        }
    }
}